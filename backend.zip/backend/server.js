console.log("THIS IS THE SERVER I AM RUNNING");
const express = require("express");
const cors = require("cors");
const mongoose=require("mongoose");
const Feedback=require("./models/Feedback");
const Alert = require("./models/Alert");
const feedbackRoutes = require("./routes/feedbackRoutes");
const alertRoutes = require("./routes/alertRoutes");
const busRoutes = require("./routes/busRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/feedback", feedbackRoutes);
app.use("/alerts", alertRoutes);
app.use("/buses", (req, res, next) => {
  console.log("Bus API called");
  next();
});
//app.use("/buses", busRoutes);
app.get("/buses",(req,res)=>{
res.send("DIRECT BUS ROUTE WORKS");
});

mongoose.connect("mongodb://127.0.0.1:27017/busproject")
.then(() => console.log("MongoDB Connected"))
.catch((err) => console.log(err));

app.get("/", (req, res) => {
   res.send("Backend is running");
});
app.get("/check",(req,res)=>{
    res.send("CHECK ROUTE WORKING");
});
const PORT = 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});