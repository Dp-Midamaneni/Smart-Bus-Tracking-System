const express=require("express");
const router = express.Router();
console.log("Bus routes loaded");
router.get("/", (re,res) =>{
    res.send("Bus route works");
});
module.exports=router;