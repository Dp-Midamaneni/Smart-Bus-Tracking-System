const express = require("express");
const router = express.Router();
const Alert = require("../models/Alert");

// Get all alerts
router.get("/", async (req, res) => {
  try {
    const alerts = await Alert.find();
    res.json(alerts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add new alert
router.post("/", async (req, res) => {
  try {
    const alert = new Alert({
      title: req.body.title,
      message: req.body.message,
    });

    const savedAlert = await alert.save();
    res.status(201).json(savedAlert);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;